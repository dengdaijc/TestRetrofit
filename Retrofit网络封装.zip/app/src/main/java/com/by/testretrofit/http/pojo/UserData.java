package com.by.testretrofit.http.pojo;

/**
 * Created by baiyu on 16/10/18.
 */

public class UserData {


    /**
     * username :
     * img :
     */

    private String username;
    private String img;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }
}
